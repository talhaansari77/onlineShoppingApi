<?php
symlink('/home/dh_z6btby/LaravelApp/storage/app/public', '/home/dh_z6btby/demobytalha.tk/storage')

// $targetFolder = $_SERVER['DOCUMENT_ROOT'].'/storage/app/public';
// $linkFolder = $_SERVER['DOCUMENT_ROOT'].'/storage';
// symlink($targetFolder,$linkFolder);

// echo 'Symlink completed';

?>