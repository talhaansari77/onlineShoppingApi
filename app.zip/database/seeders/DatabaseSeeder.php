<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();
        // $cat = \App\Models\Categories::factory()->create();

        // \App\Models\Products::factory(10)->create([
        //     'categoryId' => $cat->id
        
        // ]);
    }
}
